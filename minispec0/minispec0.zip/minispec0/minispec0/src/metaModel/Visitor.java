package metaModel;


public class Visitor {
	
	public void visitModel(Model e) {}
	public void visitEntity(Entity e) {}
	public void visitAttribute(Attribute e) {}

}
