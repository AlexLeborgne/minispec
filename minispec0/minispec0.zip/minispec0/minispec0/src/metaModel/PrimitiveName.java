package metaModel;

public class PrimitiveName {

    String nom;
    String type;
    String spackage;

    public PrimitiveName() {
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSpackage() {
        return spackage;
    }

    public void setSpackage(String spackage) {
        this.spackage = spackage;
    }
}
