package metaModel;

public interface MinispecElement {

}
