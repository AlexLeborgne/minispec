package minispecMetaModelToClass.javaGenerationParametrage.model;

public class ModelParameter extends Parameter {
}
