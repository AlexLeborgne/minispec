package minispecMetaModelToClass.javaGenerationParametrage.model;

public class PrimitiveParameter extends Parameter {
  private String className;

  public String getClassName() {
    return className;
  }

  public void setClassName(String className) {
    this.className = className;
  }
}
