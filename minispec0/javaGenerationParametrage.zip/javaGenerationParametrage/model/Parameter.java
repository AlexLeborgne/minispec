package minispecMetaModelToClass.javaGenerationParametrage.model;

public abstract class Parameter {
  private String packageName;

  public String getPackageName() {
    return packageName;
  }

  public void setPackageName(String packageName) {
    this.packageName = packageName;
  }
}
